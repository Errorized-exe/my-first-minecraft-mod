package net.mcreator.mod.item;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.mod.init.ModModFluids;

public class MilkItem extends BucketItem {
	public MilkItem(Item.Properties properties) {
		super(ModModFluids.MILK.get(), properties.craftRemainder(Items.BUCKET).stacksTo(1)

		);
	}
}