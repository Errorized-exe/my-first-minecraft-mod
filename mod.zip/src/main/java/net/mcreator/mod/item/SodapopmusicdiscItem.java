package net.mcreator.mod.item;

import net.minecraft.world.item.Item;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;

import net.mcreator.mod.ModMod;

public class SodapopmusicdiscItem extends Item {
	public SodapopmusicdiscItem(Item.Properties properties) {
		super(properties.jukeboxPlayable(ResourceKey.create(Registries.JUKEBOX_SONG, ResourceLocation.fromNamespaceAndPath(ModMod.MODID, "sodapopmusicdisc"))));
	}
}