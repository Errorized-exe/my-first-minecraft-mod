package net.mcreator.mod.fluid;

import net.neoforged.neoforge.fluids.BaseFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;

import net.mcreator.mod.init.ModModItems;
import net.mcreator.mod.init.ModModFluids;
import net.mcreator.mod.init.ModModFluidTypes;
import net.mcreator.mod.init.ModModBlocks;

public abstract class MilkFluid extends BaseFlowingFluid {
	public static final BaseFlowingFluid.Properties PROPERTIES = new BaseFlowingFluid.Properties(() -> ModModFluidTypes.MILK_TYPE.get(), () -> ModModFluids.MILK.get(), () -> ModModFluids.FLOWING_MILK.get()).explosionResistance(100f)
			.bucket(() -> ModModItems.MILK_BUCKET.get()).block(() -> (LiquidBlock) ModModBlocks.MILK.get());

	private MilkFluid() {
		super(PROPERTIES);
	}

	public static class Source extends MilkFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends MilkFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}