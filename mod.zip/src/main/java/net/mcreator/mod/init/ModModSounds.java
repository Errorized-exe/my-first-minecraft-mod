/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.sounds.SoundEvent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.registries.Registries;

import net.mcreator.mod.ModMod;

public class ModModSounds {
	public static final DeferredRegister<SoundEvent> REGISTRY = DeferredRegister.create(Registries.SOUND_EVENT, ModMod.MODID);
	public static final DeferredHolder<SoundEvent, SoundEvent> BAD_APPLE = REGISTRY.register("bad_apple", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("mod", "bad_apple")));
	public static final DeferredHolder<SoundEvent, SoundEvent> SODA_POP = REGISTRY.register("soda_pop", () -> SoundEvent.createVariableRangeEvent(ResourceLocation.fromNamespaceAndPath("mod", "soda_pop")));
}