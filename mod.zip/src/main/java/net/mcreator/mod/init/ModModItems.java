/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.mod.item.SodapopmusicdiscItem;
import net.mcreator.mod.item.MilkItem;
import net.mcreator.mod.item.BadapplemusicdiscItem;
import net.mcreator.mod.ModMod;

import java.util.function.Function;

public class ModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(ModMod.MODID);
	public static final DeferredItem<Item> MILK_BUCKET = register("milk_bucket", MilkItem::new);
	public static final DeferredItem<Item> BADAPPLEMUSICDISC = register("badapplemusicdisc", BadapplemusicdiscItem::new);
	public static final DeferredItem<Item> ERROR = block(ModModBlocks.ERROR);
	public static final DeferredItem<Item> SODAPOPMUSICDISC = register("sodapopmusicdisc", SodapopmusicdiscItem::new);

	// Start of user code block custom items
	// End of user code block custom items
	private static <I extends Item> DeferredItem<I> register(String name, Function<Item.Properties, ? extends I> supplier) {
		return REGISTRY.registerItem(name, supplier, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.registerItem(block.getId().getPath(), prop -> new BlockItem(block.get(), prop), properties);
	}
}