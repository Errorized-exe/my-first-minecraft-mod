/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.mod.ModMod;

public class ModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ModMod.MODID);
	public static final DeferredHolder<CreativeModeTab, CreativeModeTab> MOD = REGISTRY.register("mod",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.mod.mod")).icon(() -> new ItemStack(Blocks.CHAIN_COMMAND_BLOCK)).displayItems((parameters, tabData) -> {
				tabData.accept(ModModItems.MILK_BUCKET.get());
				tabData.accept(ModModItems.BADAPPLEMUSICDISC.get());
				tabData.accept(ModModBlocks.ERROR.get().asItem());
				tabData.accept(ModModItems.SODAPOPMUSICDISC.get());
			}).withSearchBar().build());
}